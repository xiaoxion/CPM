package com.stratazima.grocerlist;

/**
 * Created by esaur_000 on 10/29/2014.
 */
public class LoginFragment {
}
