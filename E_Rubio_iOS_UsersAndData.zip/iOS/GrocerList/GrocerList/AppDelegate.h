//
//  AppDelegate.h
//  GrocerList
//
//  Created by Esau Rubio on 11/4/14.
//  Copyright (c) 2014 Strtatazima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

