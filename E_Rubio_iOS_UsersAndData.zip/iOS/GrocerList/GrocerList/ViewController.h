//
//  ViewController.h
//  GrocerList
//
//  Created by Esau Rubio on 11/4/14.
//  Copyright (c) 2014 Strtatazima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UITextField *username;
    IBOutlet UITextField *password;
}

-(IBAction)onClick:(id)sender;

@end

